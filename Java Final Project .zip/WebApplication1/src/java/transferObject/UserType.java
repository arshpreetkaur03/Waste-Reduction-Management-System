package transferObject;

public enum UserType {
	Retailer,
	Consumer,
	Charitable_Organization
}
